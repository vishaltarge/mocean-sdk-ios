============================
Google AdMob Ads SDK for iOS
============================

This is the Google AdMob Ads SDK for iOS.

Requirements:
- An AdMob site ID, AdSense client ID, or DoubleClick for Publishers account
- Xcode 4.2 or later.
- Runtime of iOS 3.0 or later.

The latest documentation and code samples are available at:
http://code.google.com/mobile/ads/docs/ios
