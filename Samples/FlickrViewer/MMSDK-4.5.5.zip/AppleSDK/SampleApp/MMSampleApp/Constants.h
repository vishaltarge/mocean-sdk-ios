//
//  Constants.h
//  MMSampleApp
//
//  Created by Nolan Brown and Michael Patzer on 2/9/12.
//  Copyright (c) 2012 Millennial Media. All rights reserved.
//

#ifndef MMSampleApp_Constants_h
#define MMSampleApp_Constants_h

// Test ad APID
#define BANNER_APID @"28911"
#define CACHE_APID @"28911"
#define INTERSTITIAL_APID @"28911"

#endif
