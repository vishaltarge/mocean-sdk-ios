============================
Millennial Media SDK for iOS
============================

Requirements:
- A Millennial Media APID. (Signup at http://www.mmdev.com)
- Xcode 3.2 or later
- iOS SDK 3.2 or later

Full documentation and integration instructions are available at:
http://wiki.millennialmedia.com/index.php/IOS_SDK
