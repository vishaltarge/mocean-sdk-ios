//
//  iTennisAppDelegate.m
//  iTennis
//
//  Created by Brandon Trebitowski on 1/14/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import "iTennisAppDelegate.h"
#import "iTennisViewController.h"


@implementation iTennisAppDelegate

@synthesize window;
@synthesize viewController;

- (void) inApp: (NSTimer *) t {
	NSLog(@"Inside Function %s", __FUNCTION__);
	
	// Since this function is called in a Timer, release the previous instance to avoid memory leaks
	[inAppObject release];
	inAppObject = nil;
	
	inAppObject = [vdoAds requestInApp]; // Request an inapp object
	
	vdoApiStatus error  = [inAppObject loadAd:5.0]; // Load the Inapp ad object with ad and wait for maximum 5 seconds
	
	[NSTimer scheduledTimerWithTimeInterval:5.0 target:self selector:@selector(displayinApp:) userInfo:nil repeats:NO]; //  This API plays only in-app ads
}

- (void) displayinApp: (NSTimer *) t 
{
	[inAppObject displayAd];
}

- (void)applicationDidFinishLaunching:(UIApplication *)application {
	
	// Override point for customization after app launch    
	
    [window addSubview:viewController.view];
	
    [window makeKeyAndVisible];
	
	vdoAds=[VDOAds alloc];
	
	//TODO VDOAds: 
	//Calls the delegate methods
	vdoAds.delegate=self;
	
	//TODO: you may as well have useLocation:TRUE
	// Calling the initialization API with the API key
	[vdoAds openWithAppKey:@"AX123" useLocation:FALSE];
	
	
	// Call the API to play pre-app ad
	VDOAdObject *preApp = [vdoAds requestPreApp];
    vdoApiStatus error = [preApp loadAndDisplayAd:[UIImage imageNamed:@"Splash.PNG"] :5.0];
	if(error != vdoAPISucces)
	{
		NSLog(@"Problem playing pre-app advertisement");
	}
	
	//The following code runs inApp videos every 100 seconds
	//TODO: Modify as per requirements
	//   Typical use cases:(May need to use delegate methods)
	//   1. Use before video playback  (preroll)
	//   2. After completion of Video playback (postroll)
	//   3. Just before starting games after clicking play (inapp)
	//   4. Just after completion of a level (inapp)
	//	 5. Display a banner
	
	[NSTimer scheduledTimerWithTimeInterval:100 target:self selector:@selector(inApp:) userInfo:nil repeats:NO]; //  This API plays only in-app ads
	
	//After 40 seconds rotate a banner
	[NSTimer scheduledTimerWithTimeInterval:15 target:self selector:@selector(PlayBannerOnRequest) userInfo:nil repeats:YES];
	
}

- (void)PlayBannerOnRequest
{
	NSLog(@"Inside Function %s", __FUNCTION__);
	[ban.adObject removeFromSuperview];
	[ban release];
	ban = nil;
	
	location = top; // display a banner on top of the parent view
    
    if (UI_USER_INTERFACE_IDIOM()==UIUserInterfaceIdiomPad)
	{
		ban = [vdoAds requestBannerOfSize:@"768X90" :top];
	}
	else 
	{
		ban = [vdoAds requestBannerOfSize:@"320X75" :top];
	}
	
	if (ban == nil) 
	{
		NSLog(@"No banner of the requested size found");
		return;
	}
	
 	if([ban isReady])
    {
        [window addSubview:ban.adObject];
    }
    else
    {
        NSLog(@"Banner is not ready");
		[NSTimer scheduledTimerWithTimeInterval:3.0 target:self selector:@selector(showBanner) userInfo:nil repeats:NO];
    }
	
}

-(void)showBanner
{
	if([ban isReady])
    {
		[bannerView removeFromSuperview];
		[bannerView release];
		bannerView = NULL;
		
		if (UI_USER_INTERFACE_IDIOM()==UIUserInterfaceIdiomPad) 
		{
			if(location == 0) // Top
			{
				bannerView = [[UIView alloc] initWithFrame:CGRectMake(window.frame.origin.x, 40.0, window.frame.size.width, 90.0)];
			}
			else
			{
				bannerView = [[UIView alloc] initWithFrame:CGRectMake(window.frame.origin.x, window.frame.size.height - 90.0, window.frame.size.width, 90.0)];
			}
		}
		else
		{
			if(location == 0) // Top
			{
				bannerView = [[UIView alloc] initWithFrame:CGRectMake(0.0, 40.0, 320.0, 75.0)];
			}
			else
			{
				bannerView = [[UIView alloc] initWithFrame:CGRectMake(0.0, 460.0 - 75.0, 320.0, 75.0)];
			}
		}
		
		[window addSubview:bannerView];
        [bannerView addSubview:ban.adObject];
    }
    else
    {
        NSLog(@"Banner is not yet ready to serve");
    }
}

- (void) applicationWillTerminate:(UIApplication *)application {
	[vdoAds close];
}


- (void)dealloc {
	//[vdoAds release];
    [viewController release];
	[window release];
    [super dealloc];
}

//VDOAdsDelegate Methods
- (void) displayedBanner:(VDOAdObject*)object {
    NSLog(@ "File %s : %d",__FUNCTION__,__LINE__);
	
}

- (void) noBanner:(VDOAdObject*)object  {
    NSLog(@ "File %s : %d",__FUNCTION__,__LINE__);
	
}

- (void) playedInApp:(VDOAdObject*)object  {
    NSLog(@ "File %s : %d",__FUNCTION__,__LINE__);
	
}

- (void) noInApp:(VDOAdObject*)object  {
    NSLog(@ "File %s : %d",__FUNCTION__,__LINE__);
	
}

- (void) playedPreApp:(VDOAdObject*)object  {
    NSLog(@ "File %s : %d",__FUNCTION__,__LINE__);
	
}

- (void) noPreApp:(VDOAdObject*)object  {
    NSLog(@ "File %s : %d",__FUNCTION__,__LINE__);
	
}

- (void) bannerTapStarted:(VDOAdObject*)object  {
	NSLog(@ "File %s : %d",__FUNCTION__,__LINE__);
}

- (void) bannerTapEnded:(VDOAdObject*)object  {
	NSLog(@ "File %s : %d",__FUNCTION__,__LINE__);
}

- (void) interstitialWillShow:(VDOAdObject*)object
{	

    // If a banner is showing remove it
    [bannerView removeFromSuperview];
    [bannerView release];
    bannerView = NULL;
    
    NSLog(@ "File %s : %d",__FUNCTION__,__LINE__);
}

- (void) interstitialDidDismiss:(VDOAdObject*)object
{
    NSLog(@ "File %s : %d",__FUNCTION__,__LINE__);
}


@end
