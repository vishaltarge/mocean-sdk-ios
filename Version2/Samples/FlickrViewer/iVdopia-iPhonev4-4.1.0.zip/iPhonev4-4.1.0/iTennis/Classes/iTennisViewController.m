//
//  iTennisViewController.m
//  iTennis
//
//  Created by Brandon Trebitowski on 1/14/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import "iTennisViewController.h"

#define kGameStateRunning 1
#define kGameStatePaused  2

#define kBallSpeedX 10
#define kBallSpeedY 15

@implementation iTennisViewController
@synthesize image,ball,racquet_yellow,racquet_green,player_score,computer_score,gameState,ballVelocity,tapToBegin;

/*
// The designated initializer. Override to perform setup that is required before the view is loaded.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
	if(gameState == kGameStatePaused) {
		tapToBegin.hidden = YES;
		gameState = kGameStateRunning;
	}
}

-(void) gameLoop {
	if(gameState == kGameStateRunning) {

		ball.center = CGPointMake(ball.center.x + ballVelocity.x , ball.center.y + ballVelocity.y);
		
		if(ball.center.x > self.view.bounds.size.width || ball.center.x < 0) {
			ballVelocity.x = -ballVelocity.x;
		}
		
		if(ball.center.y > self.view.bounds.size.height || ball.center.y < 0) {
			ballVelocity.y = -ballVelocity.y;
		}
	} else {
		if(tapToBegin.hidden) {
			tapToBegin.hidden = NO;
		}
	}
}


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	CGRect fr=CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height);
	image.frame=fr;
	self.gameState = kGameStatePaused;
	ballVelocity = CGPointMake(kBallSpeedX,kBallSpeedY);
	[NSTimer scheduledTimerWithTimeInterval:0.05 target:self selector:@selector(gameLoop) userInfo:nil repeats:YES];
}



// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return YES;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
    // Release anything that's not essential, such as cached data
}

- (void)dealloc {
    [super dealloc];
	[image release];
	[ball release];
	[racquet_green release];
	[racquet_yellow release];
	[player_score release];
	[computer_score release];
	[tapToBegin release];
}

@end
