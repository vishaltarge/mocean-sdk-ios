//
//  iTennisAppDelegate.h
//  iTennis
//
//  Created by Brandon Trebitowski on 1/14/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "VDOAds.h"

@class iTennisViewController;

@interface iTennisAppDelegate : NSObject <UIApplicationDelegate, VDOAdsDelegate> {
    UIWindow *window;
    iTennisViewController *viewController;
	VDOAds * vdoAds;
	UIView *bannerView;
	VDOAdObject *ban;
	VDOAdObject *inAppObject;
	int location;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet iTennisViewController *viewController;

@end

